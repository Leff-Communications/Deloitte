const modal1 = document.querySelector('#modal-1');
const modal2 = document.querySelector('#modal-2');
const modal3 = document.querySelector('#modal-3');
const modal4 = document.querySelector('#modal-4');
const modal5 = document.querySelector('#modal-5');

const openModal1 = document.querySelector('#tile-1-hover');
const openModal2 = document.querySelector('#tile-2-hover');
const openModal3 = document.querySelector('#tile-3-hover');
const openModal4 = document.querySelector('#tile-4-hover');
const openModal5 = document.querySelector('#tile-5-hover');


openModal1.addEventListener('click', () => {
    modal1.showModal();
})

openModal2.addEventListener('click', () => {
    modal2.showModal();
})

openModal3.addEventListener('click', () => {
    modal3.showModal();
})

openModal4.addEventListener('click', () => {
    modal4.showModal();
})

openModal5.addEventListener('click', () => {
    modal5.showModal();
})